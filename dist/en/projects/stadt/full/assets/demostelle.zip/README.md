# Joint Demonstration Centre · P04-DEMO01

The three XML files contain the same specially written passage. They are XML examples in the TEI namespace, not yet an edition validated against a project ODD.

. version . Reading . . Function . .
|---|---|---|
. lesung-vorher.xml . . Tore / back here . ZXq1 before Noras correction . .
lieferstand-v1.xml Gates / this is a tested set entry level
referenzstand-v2.xml 

Hartmann's deletion "The city was ahead of it." and the marginal addition is part of the historical text genesis. Modern reading corrections are other processes. This simplified passage does not yet establish a complete chronology of historical interventions.

`erneuter-export.txt` is a didactically reduced text view, not a claimed actual transkribus export. A real PAGE/TEI export comparison is created in the next technical step. `forschungsbezug.json` documents two different research models, no executable annotation. ZX Q3 is the editorial role model.

The unit is called EH-MS01-B012R; the identifier remains the same with new dating. File names do not contain revisable chronology. A visible edge zone is added for the later demo page. IIIF endpoints and coordinates are determined only with an actual demo page.

## Read-follow demonstration P04-ORDER01

Three specially written text parts are arranged in two editorial hypotheses. The sentence positions in the manuscript are shown on a controlled SVG demo page. This is a didactic extension, not a true historical facsimile or IIIF service. Common source: reading_demo in contain/prototyp.json; Webdownload: dist/ZXq1. IDs and source positions remain the same when changing the hypothesis.
