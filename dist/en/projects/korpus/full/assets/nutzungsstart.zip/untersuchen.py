"""Lokaler Einstieg, Python-Standardbibliothek; kein Modellaufruf."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
NS={'t':'http://www.tei-c.org/ns/1.0'}
def run():
    raw=(ROOT/'korpus.xml').read_bytes();t=ET.fromstring(raw)
    riddles=t.findall('.//t:body/t:div',NS)
    ids=[x.attrib['{http://www.w3.org/XML/1998/namespace}id'] for x in riddles]
    assert len(ids)==len(set(ids))==3
    answers=t.findall('.//t:back//t:item',NS)
    refs=[x.attrib['corresp'][1:] for x in answers]
    assert len(answers)==3 and set(refs)==set(ids)
    out=ROOT/'ausgabe';out.mkdir(exist_ok=True)
    records=[]
    for key,node in zip(ids,riddles):
        lines=[]
        for line in node.findall('.//t:l',NS):
            text=(line.text or '')
            for child in line:
                text+=('[…]' if child.tag.endswith('}gap') else ''.join(child.itertext()))+(child.tail or '')
            lines.append(text)
        records.append({'id':key,'text':'\n'.join(lines),'form':node.attrib['ana'][1:]})
    solutions=[{'id':x.attrib['corresp'][1:],'solution':' '.join(' '.join(x.itertext()).split())} for x in answers]
    for name,rows in [('testeingaben',records),('loesungen',solutions)]:
        (out/(name+'.jsonl')).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf8')
    assert all('solution' not in x for x in records)
    report={'data_version':'Demo-0.2','sha256':hashlib.sha256(raw).hexdigest(),'riddles':len(ids),'solutions':len(refs),'forms':{k:sum(x['form']==k for x in records) for k in ['reimpaar','loesungsvers','reimwort']},'selection':'alle drei künstlichen Belege','checks':['XML lesbar','Kennungen eindeutig','Lösungen zugeordnet','Eingabe- und Lösungsexport getrennt'],'schema_validation':False,'model_run':False}
    (out/'ergebnis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('PASS: 3 Rätsel, 3 Lösungen; drei Formen; getrennte Exporte. Kein Modellaufruf.')
    return report
if __name__=='__main__':run()
