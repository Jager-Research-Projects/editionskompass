# Rätselhaft! – verifiable demonstration examples

All collections, texts and numbers are specially created didactic examples. They are not historical sources or research results. For them there are no real corpus releases, commit references or DOIs.

## Run

Prerequisite: Python 3 and lxml 6.1.1 (see requirements.txt). You can set up the dependency with `python -m pip install -r requirements.txt` in your own python environment. Then in the folder of this README:

```text
python run_demo.py
```

The current working environment already has lxml in the bundled Python. The specific runtime system is listed in the parent test report. The code does not load anything from the net and does not publish anything.

## What Is Tested

1. Faulty and corrected import exist the same Relax-NG-schema as well as ID and existing reference tests written specifically for the demonstration. This is not a test against a complete TEI-ODD.
2. The well-known source features – two puzzles, two solutions, matching target identifiers – distinguish the technically incorrect and corrected segmentation. The solutions may be missing in the basic model; therefore, the previous schema cannot detect the loss here itself.
3. Negative controls verify that an illicit structure or non-existing reference target is really identified.
4. Demo-v1.0 contains four puzzles (two verses / two prose), Demo-v1.1 ten (eight verses / two prosa). The two old book files are byte identical. With identical selection, two out of four puzzles remain.
5. Two XSLT selections provide different texts from the same file: just puzzles or additional solutions. Word numbers are only a visible difference, not a full-fledged historical language statistics.
6. A local sample package is created with manifest and SHA-256 values, opened and checked for completeness.

## Results

`ergebnisse/pruefbericht.json`, two TXT outputs, `probe-manifest.json` and `probe-release.zip`. The ZIP content contains the required input, scripts and documentation; a fresh unpacking can re-run the demonstration. This checks a small local transfer, non-institutional access, real archive submission or human comprehensibility.

The two segmentation versions are unpublished import candidates. The release example is independent of this: The v1.0/v1.1 there differ only by an additional book. Thus, correction and extension are not mixed.
