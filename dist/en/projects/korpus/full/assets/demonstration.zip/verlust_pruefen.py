"""Ein funktionsfähiger Analyseweg kann einen Inhaltsverlust übersehen."""
from pathlib import Path
import json,difflib
from lxml import etree
R=Path(__file__).resolve().parent
N={'t':'http://www.tei-c.org/ns/1.0'}
schema=etree.RelaxNG(etree.parse(str(R/'schema/demo.rng')))
before=etree.parse(str(R/'segmentierung/korrigiert.xml'))
after=etree.fromstring(etree.tostring(before))
back=after.find('.//t:back',N);back.getparent().remove(back)
assert schema.validate(before) and schema.validate(after)
counts=lambda t:{'riddles':len(t.xpath('//t:div[@type="riddle"]',namespaces=N)),'solutions':len(t.xpath('//t:back//t:item',namespaces=N))}
b,a=counts(before),counts(after)
assert b=={'riddles':2,'solutions':2} and a=={'riddles':2,'solutions':0}
output=R/'ergebnisse';output.mkdir(exist_ok=True)
(output/'verlust.xml').write_bytes(etree.tostring(after,pretty_print=True,encoding='UTF-8',xml_declaration=True))
report={'before':b,'after':a,'schema_before':True,'schema_after':True,'riddle_analysis_unchanged':b['riddles']==a['riddles'],'content_preserved':False}
(output/'verlustbericht.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
diff=''.join(difflib.unified_diff(etree.tostring(before,pretty_print=True,encoding='unicode').splitlines(True),etree.tostring(after,pretty_print=True,encoding='unicode').splitlines(True),fromfile='vorher.xml',tofile='nachher.xml'))
(output/'verlust.diff').write_text(diff,encoding='utf8')
print('PASS: Schema vorher/nachher erfüllt; Rätselzahl unverändert; zwei Lösungen verloren. Bestandsvergleich erkennt den Verlust.')
