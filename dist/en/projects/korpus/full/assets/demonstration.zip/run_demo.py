"""Kleine reproduzierbare Demonstration. Keine reale Datenveröffentlichung."""
from pathlib import Path
import hashlib,json,zipfile
from lxml import etree
ROOT=Path(__file__).resolve().parent
NS={'t':'http://www.tei-c.org/ns/1.0'}
SCHEMA=etree.RelaxNG(etree.parse(str(ROOT/'schema/demo.rng')))
def check(path):
 t=etree.parse(str(path));SCHEMA.assertValid(t)
 ids=t.xpath('//@xml:id',namespaces=NS)
 assert len(ids)==len(set(ids)), 'Doppelte ID'
 for v in t.xpath('//@corresp',namespaces=NS):
  for target in v.split():assert target.startswith('#') and target[1:] in ids, 'Ungueltiges Ziel'
 return t

def stats(folder):
 nodes=[]
 for p in sorted(folder.glob('*.xml')):nodes.extend(check(p).xpath('//t:div[@type="riddle"]',namespaces=NS))
 verse=sum(bool(x.find('t:lg',NS) is not None) for x in nodes)
 return {'riddles':len(nodes),'verse':verse,'prose':len(nodes)-verse,'verse_percent':100*verse/len(nodes),'ids':[x.get('{http://www.w3.org/XML/1998/namespace}id') for x in nodes]}

def source_regression(t):
 rs=t.xpath('//t:div[@type="riddle"]',namespaces=NS)
 solutions=t.xpath('//t:back//t:item',namespaces=NS)
 return len(rs)==2 and len(solutions)==2 and {x.get('corresp') for x in solutions}=={'#riddle-demo-001','#riddle-demo-002'}

def run():
 out=ROOT/'ergebnisse';out.mkdir(exist_ok=True)
 bad=check(ROOT/'segmentierung/fehlerhaft.xml');good=check(ROOT/'segmentierung/korrigiert.xml')
 assert not source_regression(bad) and source_regression(good)
 # Negative controls ensure the schema and reference tests really reject invalid input.
 broken=etree.fromstring(etree.tostring(good));broken.find('.//t:body',NS).tag='{'+NS['t']+'}unbekannt'
 assert not SCHEMA.validate(broken)
 invalid=etree.fromstring(etree.tostring(good));invalid.find('.//t:item',NS).set('corresp','#nicht-vorhanden')
 assert any(v[1:] not in invalid.xpath('//@xml:id',namespaces=NS) for v in invalid.xpath('//@corresp',namespaces=NS))
 first=stats(ROOT/'versionsvergleich/v1.0/data');second=stats(ROOT/'versionsvergleich/v1.1/data')
 assert (first['verse'],first['riddles'])==(2,4)
 assert (second['verse'],second['riddles'])==(8,10)
 # Existing source files are byte-identical; growth is confined to the added book.
 for p in (ROOT/'versionsvergleich/v1.0/data').glob('*.xml'):
  assert p.read_bytes()==(ROOT/'versionsvergleich/v1.1/data'/p.name).read_bytes()
 assert set(first['ids']).issubset(second['ids'])
 xslt=etree.XSLT(etree.parse(str(ROOT/'xslt/raetseltexte-v1.xsl')))
 alltext=etree.XSLT(etree.parse(str(ROOT/'xslt/texte-mit-loesungen-demo.xsl')))
 narrow=str(xslt(good));wide=str(alltext(good));assert 'Der Kamm.' not in narrow and 'Der Kamm.' in wide
 (out/'nur-raetsel.txt').write_text(narrow,encoding='utf8');(out/'mit-loesungen.txt').write_text(wide,encoding='utf8')
 report={'status':'künstliche Demonstration, keine historischen Befunde','segmentation':{'bad':{'schema':True,'ids_and_present_references':True,'riddles':4,'solutions':0,'source_regression':False},'corrected':{'schema':True,'ids_and_present_references':True,'riddles':2,'solutions':2,'source_regression':True}},'versions':{'v1.0':first,'v1.1':second},'unchanged_selection':{'ids':first['ids'],'riddles':4,'verse':2,'verse_percent':50},'extraction':{'riddles_only_words':len(narrow.split()),'including_solutions_words':len(wide.split())}}
 (out/'pruefbericht.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 files=[p for folder in ['versionsvergleich/v1.0/data','versionsvergleich/v1.1/data','segmentierung','schema','xslt'] for p in (ROOT/folder).glob('*') if p.is_file()]
 files.extend([ROOT/'README.md',ROOT/'requirements.txt',ROOT/'run_demo.py',ROOT/'uebergabe/pflegehandbuch.md',ROOT/'versionsvergleich/analysemanifest.json'])
 manifest={'status':'lokaler Probe-Release; nicht publiziert','example_version':'demo-v1.0','doi':None,'archive_submission':False,'files':{str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
 with zipfile.ZipFile(out/'probe-release.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,p.relative_to(ROOT))
  z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(out/'probe-release.zip') as z:
  assert z.testzip() is None
  for name,digest in manifest['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 (out/'probe-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 print('PASS: beide Importe strukturgültig; Quellenregression erkennt Fehlsegmentierung.')
 print('PASS: v1.0 2/4 = 50%; v1.1 8/10 = 80%; identische Alt-Auswahl 50%.')
 print('PASS: Extraktionen unterscheiden sich; lokales Probe-Paket vollständig und Prüfsummen bestätigt.')
if __name__=='__main__':run()
