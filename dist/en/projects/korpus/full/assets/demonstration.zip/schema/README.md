# Test scope of the demonstration

This small Relax-NG-schema is specially written for the sample files. It is not a complete corpus specification generated from a TEI-ODD and no evidence of comprehensive TEI conformity. The element and reference examples are located in the TEI namespace.

The displayed text structure and selected attributes are checked here. The header is deliberately only modeled as an existing, any further structured block. The additional Python checks control ID clarity and existing local references. Solutions are optional because not every collection that has passed down.

The scope of the test does not know the source: it cannot decide whether "The comb is a riddle or a solution. For this well-known test template is additionally defined: two puzzles, two solutions and the expected target identifiers. Exactly this regression test fails with faulty import.
