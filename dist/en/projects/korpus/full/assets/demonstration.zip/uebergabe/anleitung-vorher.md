# Insufficient handover note

Check out the data, run the tests and generate the export as usual. Then prepare the package for the archive.

## Gaps visible in the test

Which data stand? Which tool set? What selection? Which file list and checksum? What check result can be expected? Who may archive and publish? The following person must not have to guess exactly this information.
