# Gemeinsame Demostelle · P04-DEMO01

Die drei XML-Dateien enthalten dieselbe eigens verfasste Passage. Sie sind XML-Lehrbeispiele im TEI-Namensraum, noch keine gegen ein Projekt-ODD validierte Edition.

| Stand | Lesung | Funktion |
|---|---|---|
| lesung-vorher.xml | Thore / hierher | Arbeitsstand vor Noras Korrektur |
| lieferstand-v1.xml | Tore / hierher | Geprüfter Satz-Eingangsstand |
| referenzstand-v2.xml | Tore / dorthin | Fachliche Korrektur aus der Fahne zurückgeführt |

Hartmanns Streichung „Die Stadt lag vor ihr.“ und der Randzusatz gehören zur historischen Textgenese. Die modernen Lesungskorrekturen sind andere Vorgänge. Diese vereinfachte Stelle legt noch keine vollständige Chronologie der historischen Eingriffe fest.

`erneuter-export.txt` ist eine didaktische reduzierte Textansicht, kein behaupteter tatsächlicher Transkribus-Export. Ein echter PAGE-/TEI-Exportvergleich wird im nächsten technischen Arbeitsschritt angelegt. `forschungsbezug.json` dokumentiert zwei unterschiedliche Forschungsmodelle, keine ausführbare Annotation. `zugangsmatrix.json` ist das redaktionelle Rollenmodell.

Die Einheit heißt EH-MS01-B012R; die Kennung bleibt bei neuer Datierung gleich. Dateinamen enthalten keine revidierbare Chronologie. Für die spätere Demoseite wird eine sichtbare Randzone ergänzt. IIIF-Endpunkte und Koordinaten werden erst mit einer tatsächlichen Demoseite festgelegt.

## Lesefolgen-Demonstration P04-ORDER01

Drei eigens verfasste Textteile werden in zwei editorischen Hypothesen angeordnet. Die Satzpositionen im Manuskript werden auf einer kontrolliert gesetzten SVG-Demoseite gezeigt. Das ist eine didaktische Erweiterung, kein echter historischer Faksimile- oder IIIF-Dienst. Gemeinsame Quelle: reading_demo in inhalte/prototyp.json; Webdownload: dist/lesefolgen.json. IDs und Quellpositionen bleiben beim Wechsel der Hypothese gleich.
