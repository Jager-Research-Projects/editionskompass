# Unzureichende Übergabenotiz

Die Daten auschecken, die Tests ausführen und den Export wie üblich erzeugen. Dann das Paket für das Archiv vorbereiten.

## Im Test sichtbare Lücken

Welcher Datenstand? Welche Werkzeugfassung? Welche Auswahl? Welche Dateiliste und Prüfsumme? Welches Prüfergebnis ist zu erwarten? Wer darf archivieren und veröffentlichen? Genau diese Informationen darf die nachfolgende Person nicht erraten müssen.
