# Rätselhaft! – überprüfbare Demonstrationsbeispiele

Alle Sammlungen, Texte und Bestandszahlen sind eigens erstellte didaktische Beispiele. Sie sind keine historischen Quellen oder Forschungsergebnisse. Es existieren für sie keine echten Korpusreleases, Commitreferenzen oder DOIs.

## Ausführen

Voraussetzung: Python 3 und lxml 6.1.1 (siehe requirements.txt). In einer eigenen Python-Umgebung lässt sich die Abhängigkeit mit `python -m pip install -r requirements.txt` einrichten. Danach im Ordner dieser README:

```text
python run_demo.py
```

Die aktuelle Arbeitsumgebung verfügt bereits über lxml im gebündelten Python. Das konkrete Laufzeitsystem ist im übergeordneten Prüfbericht verzeichnet. Der Code lädt nichts aus dem Netz und veröffentlicht nichts.

## Was geprüft wird

1. Fehlerhafter und korrigierter Import bestehen dasselbe eigens für die Demonstration geschriebene Relax-NG-Schema sowie ID- und vorhandene Referenzprüfungen. Das ist keine Prüfung gegen eine vollständige TEI-ODD.
2. Die bekannten Quellenmerkmale – zwei Rätsel, zwei Lösungen, passende Zielkennungen – unterscheiden die fachlich falsche und die korrigierte Segmentierung. Die Lösungen dürfen im Basismodell fehlen; deshalb kann das bisherige Schema den Verlust hier nicht selbst erkennen.
3. Negative Kontrollen prüfen, dass eine unerlaubte Struktur bzw. ein nicht vorhandenes Verweisziel wirklich erkannt werden.
4. Demo-v1.0 enthält vier Rätsel (zwei Vers / zwei Prosa), Demo-v1.1 zehn (acht Vers / zwei Prosa). Die beiden alten Buchdateien sind bytegleich. Bei identischer Auswahl bleiben zwei von vier Versrätsel erhalten.
5. Zwei XSLT-Auswahlen liefern aus derselben Datei unterschiedliche Texte: nur Rätsel oder zusätzlich Lösungen. Die Wortzahlen sind nur ein sichtbarer Unterschied, keine vollwertige historische Sprachstatistik.
6. Ein lokales Probe-Paket wird mit Manifest und SHA-256-Werten erstellt, geöffnet und auf Vollständigkeit geprüft.

## Ergebnisse

`ergebnisse/pruefbericht.json`, zwei TXT-Ausgaben, `probe-manifest.json` und `probe-release.zip`. Der ZIP-Inhalt enthält die benötigten Eingaben, Skripte und Dokumentation; eine frische Entpackung kann die Demonstration erneut ausführen. Dies prüft eine kleine lokale Übergabe, nicht institutionelle Zugänge, reale Archiveinreichung oder menschliche Verständlichkeit.

Die beiden Segmentierungsfassungen sind unveröffentlichte Importkandidaten. Das Releasebeispiel ist unabhängig davon aufgebaut: Die dortigen v1.0/v1.1 unterscheiden sich ausschließlich durch ein zusätzliches Buch. So werden Korrektur und Erweiterung nicht vermischt.
