# Prüfumfang der Demonstration

Dieses kleine Relax-NG-Schema ist eigens für die Beispieldateien geschrieben. Es ist keine aus einer TEI-ODD generierte vollständige Korpusspezifikation und kein Nachweis umfassender TEI-Konformität. Die Element- und Verweisbeispiele stehen im TEI-Namensraum.

Geprüft werden hier die gezeigte Textstruktur und ausgewählte Attribute. Der Header ist bewusst nur als vorhandener, beliebig weiter strukturierter Block modelliert. Die zusätzlichen Python-Prüfungen kontrollieren ID-Eindeutigkeit und vorhandene lokale Verweise. Lösungen sind optional, weil nicht jede Sammlung welche überliefert.

Der Prüfumfang kennt die Quelle nicht: Er kann nicht entscheiden, ob „Der Kamm.“ ein Rätsel oder eine Lösung ist. Für diese bekannte Testvorlage ist zusätzlich festgelegt: zwei Rätsel, zwei Lösungen und die erwarteten Zielkennungen. Genau dieser Regressionstest scheitert beim fehlerhaften Import.
